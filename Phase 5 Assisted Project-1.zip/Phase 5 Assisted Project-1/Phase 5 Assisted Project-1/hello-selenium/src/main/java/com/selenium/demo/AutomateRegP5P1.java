package com.selenium.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AutomateRegP5P1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Phase5 Selenium\\chrome driver\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.shine.com/registration/");
		
		//name
		WebElement name=driver.findElement(By.id("id_name"));
		name.sendKeys("Josh");
		
		//email
		WebElement email=driver.findElement(By.id("id_email"));
		email.sendKeys("Joshbosh123@foxisports.cf");
		
		//mobile
		WebElement mobile=driver.findElement(By.id("id_cell_phone"));
		mobile.sendKeys("9843345678");
		
		//password
		WebElement password=driver.findElement(By.id("id_password"));
		password.sendKeys("Nive@123");
		
		//button
		WebElement register=driver.findElement(By.cssSelector("#registerButton"));
		register.click();
		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Registration Personal')]")));

        // Select gender - You can choose Male, Female, Non-binary, or Prefer not to say based on your needs
        //WebElement genderOption = driver.findElement(By.xpath("//label[text()='Male']"));
        //genderOption.click();
	}
}