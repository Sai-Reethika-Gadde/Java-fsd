import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.ecommerce.DBConnection;

@WebServlet("/DisplayDataServlet")
public class DisplayDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DisplayDataServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            out.println("<html><body>");

            // Obtain the database connection details from config.properties
            InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties");
            Properties props = new Properties();
            props.load(in);

            // Initialize the database connection
            DBConnection conn = new DBConnection(props.getProperty("url"), props.getProperty("userid"),
                    props.getProperty("password"));

            out.println("DB Connection initialized.<br>");

            // Retrieve and display data from the database (example query)
            Statement statement = conn.getConnection().createStatement();
            System.out.println("Before executing query"); // Log to console
            ResultSet resultSet = statement.executeQuery("SELECT * FROM employees");
            System.out.println("After executing query"); // Log to console

            // Log the column names
            System.out.println("Column Names: employee_id, first_name, last_name, salary");
            
            int rowCount = 0;
            while (resultSet.next()) {
            	rowCount++;
                // Process each row of the result set and display data
                int employeeId = resultSet.getInt("employee_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                double salary = resultSet.getDouble("salary");

                // Log information to console
                System.out.println("Processing row: " + employeeId + ", " + firstName + " " + lastName + ", " + salary);

                // Print to HTML output
                out.println("Employee ID: " + employeeId + ", Name: " + firstName + " " + lastName + ", Salary: " + salary + "<br>");
            }

            // Close the database connection
            conn.closeConnection();
            out.println("DB Connection closed.<br>");

            out.println("</body></html>");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage() + "<br>");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
