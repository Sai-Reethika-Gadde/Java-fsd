package typeCasting;

public class TypeCasting {
	
	public static void main(String[] args) {
		
		// Implicit Type Casting (Widening)
        byte byteValue = 50;
        short shortValue = byteValue;  // byte can be assigned to short implicitly
        int intValue = shortValue;     // short can be assigned to int implicitly
        long longValue = intValue;     // int can be assigned to long implicitly
        float floatValue = longValue;   // long can be assigned to float implicitly
        double doubleValue = floatValue; // float can be assigned to double implicitly

        System.out.println("Implicit Type Casting:");
        System.out.println("byteValue: " + byteValue);
        System.out.println("shortValue: " + shortValue);
        System.out.println("intValue: " + intValue);
        System.out.println("longValue: " + longValue);
        System.out.println("floatValue: " + floatValue);
        System.out.println("doubleValue: " + doubleValue);

        // Explicit Type Casting (Narrowing)
        double doubleVal = 35.26;
        float floatVal = (float) doubleVal; // double must be explicitly cast to float
        long longVal = (long) floatVal;     // float must be explicitly cast to long
        int intVal = (int) longVal;          // long must be explicitly cast to int
        short shortVal = (short) intVal;    // int must be explicitly cast to short
        byte byteVal = (byte) shortVal;     // short must be explicitly cast to byte

        System.out.println("\nExplicit Type Casting:");
        System.out.println("doubleVal: " + doubleVal);
        System.out.println("floatVal: " + floatVal);
        System.out.println("longVal: " + longVal);
        System.out.println("intVal: " + intVal);
        System.out.println("shortVal: " + shortVal);
        System.out.println("byteVal: " + byteVal);
    }
}